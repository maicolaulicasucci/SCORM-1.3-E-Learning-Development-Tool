/*
 *
 *
 * Copyright (C) 2014 Maicol Auli Casucci <trinita87 at hotmail.it>. 
 *
 * This file is part of SCORM (1.3) E-learning Development Tool.
 * SCORM (1.3) E-learning Development Tool is free software: you can 
 * redistribute it and/or modify it under the terms of the GNU Lesser General 
 * Public License as published by the Free Software Foundation, either version 
 * 3 of the License, or (at your option) any later version.
 *
 * SCORM (1.3) E-learning Development Tool is distributed in the hope that it 
 * will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SCORM (1.3) E-learning Development Tool 
 * (Desktop/Licenses/lgpl.txt).  
 * If not, see <http://www.gnu.org/licenses/lgpl.html> and 
 * <http://www.gnu.org/licenses/gpl.html>.
 *
 */
package wizard;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Maicol Auli Casucci
 */
public class OpenJS {
    
    /*
    This class counts the existing pages of the course and points to the last page added.
    */

    private StringBuffer buffer;
    private char lastSectionAdded;
    private int lastNumberAdded;
    
    public OpenJS(String filename) {
        lastSectionAdded = '0';  //default values if the pages.js file doesn't exist,
        lastNumberAdded = -1;    //or if the section and number are not found.
        File name = new File(filename);
        buffer = new StringBuffer();
        if (name.isFile()) {
            try {
                /*
                Looking for the section of the last page added to the course.
                */
                BufferedReader input = new BufferedReader(new FileReader(name));
                String text;
                while ((text = input.readLine()) != null) {
                    if (!text.trim().equals("});")) {  //removal of the brackets
                        buffer.append(text + "\n");
                    }
                }
                input.close(); //file closed
                /*
                We use regular expressions to search the code of the last section added;
                if this is not found we create a new list of pages (pages.js).
                */
                Pattern pattern = Pattern.compile("\"([IPARF])\"");
                //the pattern will search only for I-P-A-R-F codes inside the document
                Matcher m = pattern.matcher(buffer.toString());
                String s = "";
                while (m.find()) { 
                //we scan all the results until we find the last one
                    s = m.group(1);
                }
                if (!s.isEmpty()) {
                    lastSectionAdded = s.charAt(0); //last section value stored in the var
                }
                /*
                Then we look for the last page added. If the result is empty we create a new file
                */
                pattern = Pattern.compile("\\[(.*?)\\]");
                m = pattern.matcher(buffer.toString());
                s = "";
                while (m.find()) { 
                    s = m.group(1);
                }
                if (!s.isEmpty()) {
                    lastNumberAdded = Integer.parseInt(s); //last page value stored in the var
                }
                
            } catch (IOException ioException) {//file does not exist
                
            }
        } 
    }
    
    public StringBuffer getBuffer() {
        return buffer; //returns the content of the file
    }
    
    public char getLastSection() {
        return lastSectionAdded; //returns the last section added
    }
    
    public int getLastNumber() {
        return lastNumberAdded; //returns the number of the last page added
    }
}
