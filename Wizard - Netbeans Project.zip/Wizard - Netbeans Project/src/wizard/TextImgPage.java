/*
 *
 *
 * Copyright (C) 2014 Maicol Auli Casucci <trinita87 at hotmail.it>. 
 *
 * This file is part of SCORM (1.3) E-learning Development Tool.
 * SCORM (1.3) E-learning Development Tool is free software: you can 
 * redistribute it and/or modify it under the terms of the GNU Lesser General 
 * Public License as published by the Free Software Foundation, either version 
 * 3 of the License, or (at your option) any later version.
 *
 * SCORM (1.3) E-learning Development Tool is distributed in the hope that it 
 * will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SCORM (1.3) E-learning Development Tool 
 * (Desktop/Licenses/lgpl.txt).  
 * If not, see <http://www.gnu.org/licenses/lgpl.html> and 
 * <http://www.gnu.org/licenses/gpl.html>.
 *
 */
package wizard;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author Maicol Auli Casucci
 */
public class TextImgPage extends javax.swing.JFrame implements ActionListener {

    /**
     * Frame called when the user wants to add a new text page with 1-2 images to the course.
     * 
     */
    private MainPage principale;
    private File img1, img2;
    private boolean quiz;
    
    public TextImgPage() {
        initComponents();
    }

    TextImgPage(MainPage aThis) {
        initComponents();
        principale = aThis;
        JFormattedTextField tf = ((JSpinner.DefaultEditor)compTime.getEditor()).getTextField();
        tf.setEditable(false); //Completion time
        updateSecCombo(principale.lastSectionAdded, true); //combobox update (forced)
        this.img1 = null;
        this.img2 = null;
        quiz = false; //to add a test to the course the user needs to select it 
                      //from the combobox
        principale.setVisible(false); //main frame hidden
        secCombo.addActionListener(this); //new listener added to the combobox, to check
                                          //the selection
    }
    
    private void updateSecCombo(char added, boolean setup) {
        /*
        This method manages the combobox that shows the section where the user can
        add a page.
        The combobox has to "guide" and force the user to follow the selection I-P-A-R-F:
        I = the user needs to add at least one introduction page
        P = the user needs to add at least one question in the pre-test
        A = the user needs to add at least one content page
        R = the user needs to add at least one summary page
        F = the user needs to add at least one question in the final test (score saved)
        */
        if (added != principale.lastSectionAdded || setup) {
            secCombo.removeAllItems();
            if (added == '0') {
                secCombo.addItem("Introduction");
            }
            if (added == 'I') {
                secCombo.addItem("Introduction");
                secCombo.addItem("Pre-test");
            }
            if (added == 'P') {  //the user needs to add at least one content page
                secCombo.addItem("Content");
            }
            if (added == 'A') {
                secCombo.addItem("Content");
                secCombo.addItem("Summary");
            }
            if (added == 'R') {
                secCombo.addItem("Summary");
                secCombo.addItem("Final test");
            }
            principale.lastSectionAdded = added;
        }
    }
    
    private char getSectionSelected() {
        /*
        This method returns the code (I-P-A-R-F) depending on the user selection.
        */
        String section = secCombo.getSelectedItem().toString();
        switch (section) {
            case "Introduction":    return 'I';
            case "Pre-test":        return 'P';
            case "Content":         return 'A';
            case "Summary":         return 'R';
            case "Final test":      return 'F';
        }
        return '0';
    }
    
    private void createJS() {
        /*
        This method updates the pages.js buffer. Refer to TextPage.java for the comments.
        */
        if (!quiz) {
            if (principale.lastSectionAdded == '0') { 
                principale.buffer.setLength(0);
                principale.buffer.append("$(document).ready(function(e) {"
                        + "\npages["
                        + (principale.lastNumberAdded + 1)
                        + "] = new page(\"contents/page"
                        + (principale.lastNumberAdded + 1)
                        + ".html\",\""
                        + getSectionSelected()
                        + "\",\""
                        + titleField.getText()
                        + "\",false, false);\n");
            } else { 
                principale.buffer.append("pages["
                        + (principale.lastNumberAdded + 1)
                        + "] = new page(\"contents/page"
                        + (principale.lastNumberAdded + 1)
                        + ".html\",\""
                        + getSectionSelected()
                        + "\",\""
                        + titleField.getText()
                        + "\",false, false);\n");
            }
        } else {
            principale.buffer.append("pages["
                    + (principale.lastNumberAdded + 1)
                    + "] = new page(\"contents/test.html\",\""
                    + getSectionSelected()
                    + "\",\"");
            if (getSectionSelected() == 'P') {
                principale.buffer.append("Pre-test");
            } else {
                principale.buffer.append("Final test");
            }
            principale.buffer.append("\",false, false);\n");
        }
    }
    
    private void createHtml() { 
        /*
        html page building
        */
        String html = "<!doctype html>\n" +   //html init
                "<html>\n" +
                "<head>\n" +
                "<meta charset=\"UTF-8\">\n";
        html += "<title>"+titleField.getText()+"</title>\n"; //title of the page
        html += "<style type=\"text/css\">\n" +
                "   @import url(\"css/LayoutText.css\");\n" +  
                "   @import url(\"css/LayoutImg.css\");\n" +
                "</style>\n" +
                "<script type=\"text/javascript\">\n" + //script js
                "$(document).ready(function(){\n" +
                "setTimeout(\n" +
                "  function() \n" +
                "  {\n" +
                "   if (!$(\"#m\"+currentPage).hasClass(\"completed\")) {\n" +
                "       pages[currentPage].completed = true;\n" +
                "       $(\"#m\"+currentPage).addClass(\"completed\");\n" +
                "   }\n" +
                "  }, " +
                compTime.getValue().toString() + "000" + //completion time
                ");\n" +
                "});\n";
        if (addAnimation.isSelected()) {  //animation (if selected)
            html += "$(\".ajax-font\").hide();\n"
                    + "$(\".ajax-img\").hide();\n"
                    + "$(\".ajax-img\").fadeIn(1000);\n"
                    + "$(\".ajax-font\").fadeIn(2000);\n";            
        }
        html+=  "</script>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"ajax-window\">\n" +
                "<div class=\"ajax-imgs-container align-center\">\n";
        if (fileName1.isEnabled()) {
            /*
            Check if image1 was added (mandatory).
            */
            html += "<img class=\"ajax-img\" src=\"images/page"+
                    (principale.lastNumberAdded+1) +
                    "/"+ //Filename edited, same extension of the original file.
                    fileName1.getText() +"."+ FilenameUtils.getExtension(img1.getName()) +
                    "\">";
            // The image file is copied to the "images" folder under the pageN folder,
            // where N is the page number of the course.
            copyFile(img1,fileName1.getText() +"."+ FilenameUtils.getExtension(img1.getName()));
        }
        if (fileName2.isEnabled()) {
            /*
            Same for image2.
            */
            html += "<img class=\"ajax-img\" src=\"images/page"+
                    (principale.lastNumberAdded+1) +
                    "/"+
                    fileName2.getText() +"."+ FilenameUtils.getExtension(img2.getName()) +
                    "\">";
            copyFile(img2,fileName2.getText() +"."+ FilenameUtils.getExtension(img2.getName()));
        }
        html += "<p class=\"ajax-font\">"+parTextArea.getText().replaceAll("\n", "<br>")+"</p>\n";
        html += "</div>\n" +
                "</body>\n" +
                "</html>\n";
        saveHtml(html);
    }
    
    private void saveHtml(String html) {
        /*
        This method save the html string inside a file named: pageN.html, with 
        N = last number of page added. With this rule we will be able to find the last 
        page added and continue adding pages from that.
        */
        try {
            File file = new File("emptyCourse/content/contents/page"
                    +(principale.lastNumberAdded+1)
                    +".html");
            FileWriter fw = new FileWriter(file);
            fw.write(html);
            fw.flush();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void cleanFields() {
        img1 = null;
        img2 = null;
        parTextArea.setText(null);
        fileName1.setText("File name");
        fileName2.setText("File name");
        fileName1.setEnabled(false);
        fileName2.setEnabled(false);
        titleField.setText(null);
    }
    
    private File loadImg(){
        /*
        This method load the files chosen by the user.
        It uses a Filter object, to make selectable only the images files.
        */
        JFileChooser chooser = new JFileChooser("../"); //Parent folder
                                                   
        chooser.setDialogTitle("Choose image"); //Title
        chooser.setFileFilter(new ImgFileFilter()); //New image filter
        chooser.setMultiSelectionEnabled(false);  //The user can select only one file
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY); 
        int n = chooser.showOpenDialog(this); 
        if (n==JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile(); 
        }
        return null;
    }
    
    private void copyFile(File source, String destName) {
        /*
        This method copies the chosen file to the "images" folder.
        */
        File dest = new File("emptyCourse/content/images/page"
                + (principale.lastNumberAdded+1)
                +"/"
                + destName);
        try {
            FileUtils.copyFile(source, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        chooseImg1 = new javax.swing.JButton();
        compTime = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        secLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        titleField = new javax.swing.JTextField();
        secCombo = new javax.swing.JComboBox();
        compTimeLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        fileName1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        chooseImg2 = new javax.swing.JButton();
        fileName2 = new javax.swing.JTextField();
        par1Label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        parTextArea = new javax.swing.JTextArea();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        export = new javax.swing.JButton();
        addAnimation = new javax.swing.JCheckBox();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Create page with text and images");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        chooseImg1.setText("Choose image");
        chooseImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseImg1ActionPerformed(evt);
            }
        });

        compTime.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        compTime.setEditor(new javax.swing.JSpinner.NumberEditor(compTime, ""));

        jLabel2.setText("seconds");

        secLabel.setText("*Course section:");

        jLabel1.setText("*Page title:");

        secCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Introduzione" }));

        compTimeLabel.setText("Minimum time required on page:");

        jLabel3.setText("*Image 1:");

        fileName1.setText("File name");
        fileName1.setEnabled(false);

        jLabel4.setText("Image 2:");

        chooseImg2.setText("Choose image");
        chooseImg2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseImg2ActionPerformed(evt);
            }
        });

        fileName2.setText("File name");
        fileName2.setEnabled(false);

        par1Label.setText("*Paragraph:");

        parTextArea.setColumns(20);
        parTextArea.setLineWrap(true);
        parTextArea.setRows(5);
        jScrollPane1.setViewportView(parTextArea);

        jLayeredPane1.setLayout(new java.awt.FlowLayout());

        export.setText("Add page to course");
        export.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportActionPerformed(evt);
            }
        });
        jLayeredPane1.add(export);

        addAnimation.setSelected(true);
        addAnimation.setText("Add animation");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("* required fields");

        jLabel5.setFont(new java.awt.Font("Lucida Fax", 0, 8)); // NOI18N
        jLabel5.setText("Recommended max 30 characters.");

        jLabel6.setFont(new java.awt.Font("Lucida Fax", 0, 8)); // NOI18N
        jLabel6.setText("Recommended max 100 words");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLayeredPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(par1Label)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel7))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(chooseImg1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(chooseImg2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(secLabel)
                                                .addGap(25, 25, 25)
                                                .addComponent(secCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(addAnimation))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel6))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(fileName2, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(fileName1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addComponent(titleField))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(compTimeLabel)
                                        .addGap(18, 18, 18)
                                        .addComponent(compTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(secLabel)
                    .addComponent(secCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(compTimeLabel)
                    .addComponent(compTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(chooseImg1)
                    .addComponent(fileName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(chooseImg2)
                    .addComponent(fileName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(par1Label)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addAnimation)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void chooseImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseImg1ActionPerformed
        /*
        The user wants to add the first image to the page.
        */
        img1 = loadImg(); 
        if (img1 != null) {
            fileName1.setEnabled(true); // The filename is editable.
            fileName1.setText(FilenameUtils.removeExtension(img1.getName()));
        }
    }//GEN-LAST:event_chooseImg1ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        principale.setVisible(true);   //Back to the main frame.
    }//GEN-LAST:event_formWindowClosed

    private void chooseImg2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseImg2ActionPerformed
        /*
        Second image.
        */
        img2 = loadImg();
        if (img2 != null) {
            fileName2.setEnabled(true);
            fileName2.setText(FilenameUtils.removeExtension(img2.getName()));
        }
    }//GEN-LAST:event_chooseImg2ActionPerformed

    private void exportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportActionPerformed
        /*
        The user clicked the button to add the page to the course. Refer to 
        TextPage.java for the comments. 
        Blank filenames not allowed.
        */
        if (!quiz) {
            if (titleField.getText().trim().isEmpty() || parTextArea.getText().trim().isEmpty()
                    || !fileName1.isEnabled() || fileName1.getText().trim().isEmpty() ||
                    (fileName2.isEnabled() && fileName2.getText().trim().isEmpty())) {
                JOptionPane.showMessageDialog(this, "Please complete all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                createHtml();
                createJS();
                JOptionPane.showMessageDialog(this, "Page added to section -"
                        + secCombo.getSelectedItem().toString()
                        + "-", "Message", JOptionPane.INFORMATION_MESSAGE);
                principale.lastNumberAdded++;
                updateSecCombo(getSectionSelected(), false);
                cleanFields();
            }
        } else {
            Quiz q = new Quiz(getSectionSelected(), this, principale);
            this.setVisible(false);
            q.setVisible(true);
            createJS();
            principale.lastNumberAdded++;
            updateSecCombo(getSectionSelected(), false);
        }
    }//GEN-LAST:event_exportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TextImgPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TextImgPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TextImgPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TextImgPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TextImgPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox addAnimation;
    private javax.swing.JButton chooseImg1;
    private javax.swing.JButton chooseImg2;
    private javax.swing.JSpinner compTime;
    private javax.swing.JLabel compTimeLabel;
    private javax.swing.JButton export;
    private javax.swing.JTextField fileName1;
    private javax.swing.JTextField fileName2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel par1Label;
    private javax.swing.JTextArea parTextArea;
    private javax.swing.JComboBox secCombo;
    private javax.swing.JLabel secLabel;
    private javax.swing.JTextField titleField;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        /*
        Same method of TextPage.java.
        */
        try {
            if (((JComboBox) e.getSource()).getSelectedItem().equals("Final test")
                    || ((JComboBox) e.getSource()).getSelectedItem().equals("Pre-test")) {
                cleanFields();
                titleField.setEnabled(false);
                compTime.setEnabled(false);
                parTextArea.setEnabled(false);
                par1Label.setEnabled(false);
                addAnimation.setEnabled(false);
                chooseImg1.setEnabled(false);
                chooseImg2.setEnabled(false);
                fileName1.setEnabled(false);
                fileName2.setEnabled(false);
                quiz = true;
            } else {
                if (!titleField.isEnabled()) {
                    titleField.setEnabled(true);
                    compTime.setEnabled(true);
                    par1Label.setEnabled(true);
                    parTextArea.setEnabled(true);
                    addAnimation.setEnabled(true);
                    chooseImg1.setEnabled(true);
                    chooseImg2.setEnabled(true);
                    quiz = false;
                }
            }
        } catch (Exception ex) {
        }    
    }
}
