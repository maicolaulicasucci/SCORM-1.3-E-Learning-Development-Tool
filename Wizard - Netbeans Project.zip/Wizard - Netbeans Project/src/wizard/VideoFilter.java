/*
 *
 *
 * Copyright (C) 2014 Maicol Auli Casucci <trinita87 at hotmail.it>. 
 *
 * This file is part of SCORM (1.3) E-learning Development Tool.
 * SCORM (1.3) E-learning Development Tool is free software: you can 
 * redistribute it and/or modify it under the terms of the GNU Lesser General 
 * Public License as published by the Free Software Foundation, either version 
 * 3 of the License, or (at your option) any later version.
 *
 * SCORM (1.3) E-learning Development Tool is distributed in the hope that it 
 * will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SCORM (1.3) E-learning Development Tool 
 * (Desktop/Licenses/lgpl.txt).  
 * If not, see <http://www.gnu.org/licenses/lgpl.html> and 
 * <http://www.gnu.org/licenses/gpl.html>.
 *
 */
package wizard;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author Maicol Auli Casucci
 */
public class VideoFilter extends FileFilter{
    
    /**
     * 
     * Only mp4, ogv and webm files are supported. 
     * These are the extensions commonly opened by smartphones. 
     */

    @Override
    public boolean accept(File file) {
        if (file.isDirectory()) {
            return true;
        }
        String fname = file.getName().toLowerCase();
        return (fname.endsWith("mp4") || fname.endsWith("ogv") || fname.endsWith("webm"));    
    }

    @Override
    public String getDescription() {
        return "Video file";
    }
    
}
