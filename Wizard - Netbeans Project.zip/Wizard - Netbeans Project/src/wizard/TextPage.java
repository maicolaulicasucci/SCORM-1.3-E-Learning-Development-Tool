/*
 *
 *
 * Copyright (C) 2014 Maicol Auli Casucci <trinita87 at hotmail.it>. 
 *
 * This file is part of SCORM (1.3) E-learning Development Tool.
 * SCORM (1.3) E-learning Development Tool is free software: you can 
 * redistribute it and/or modify it under the terms of the GNU Lesser General 
 * Public License as published by the Free Software Foundation, either version 
 * 3 of the License, or (at your option) any later version.
 *
 * SCORM (1.3) E-learning Development Tool is distributed in the hope that it 
 * will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SCORM (1.3) E-learning Development Tool 
 * (Desktop/Licenses/lgpl.txt).  
 * If not, see <http://www.gnu.org/licenses/lgpl.html> and 
 * <http://www.gnu.org/licenses/gpl.html>.
 *
 */
package wizard;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.paint.Color;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.border.LineBorder;

/**
 *
 * @author Maicol Auli Casucci
 */
public class TextPage extends javax.swing.JFrame implements ActionListener {

    /**
     * Frame called when the user wants to add a new text page to the course.
     */
    private MainPage principale;
    private boolean quiz;
    
    public TextPage() {
        initComponents();
    }

    TextPage(MainPage aThis) {
        initComponents();
        principale = aThis; //main frame
        updateSecCombo(principale.lastSectionAdded, true); //section update (forced)
        this.quiz = false; //to add a test to the course the user needs to select it 
                           //from the combobox
        //time editor disabled, so the user needs to use the buttons
        ((DefaultEditor) compTime.getEditor()).getTextField().setEditable(false); 
        
        principale.setVisible(false); //main frame hidden
        secCombo.addActionListener(this); //new listener added to the combobox, to check
                                          //the selection
    }
    
    private void createHtml() { 
        /*
        html page building
        */
        String html = "<!doctype html>\n" +   //html init
                "<html>\n" +
                "<head>\n" +
                "<meta charset=\"UTF-8\">\n";
        html += "<title>"+titleField.getText()+"</title>\n"; //title of the page
        html += "<style type=\"text/css\">\n" +
                "   @import url(\"css/LayoutText.css\");\n" +  
                "</style>\n" +
                "<script type=\"text/javascript\">\n" +   //script js
                "$(document).ready(function(){\n" +
                "setTimeout(\n" +
                "  function() \n" +
                "  {\n" +
                "   if (!$(\"#m\"+currentPage).hasClass(\"completed\")) {\n" +
                "       pages[currentPage].completed = true;\n" +
                "       $(\"#m\"+currentPage).addClass(\"completed\");\n" +
                "   }\n" +
                "  }, " +
                compTime.getValue().toString() + "000" +  //completion time
                ");\n" +
                "});\n";
        if (addAnimation.isSelected()) {  //animation (if selected)
            html += "$(\".ajax-font\").hide();\n";
            for (int i=0;i<=parNumCombo.getSelectedIndex();i++) {
                html += "$(\".ajax-font\").eq("+i+").fadeIn("+((i+1)*1000)+");\n";
            }
        }
        html+=  "</script>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"ajax-window\">\n";
        /*
        Depending on the number of paragraphs, we add the respective elements to the html page.
        */
        if (parNumCombo.getSelectedIndex()>=0)
            html += "<p class=\"ajax-font\">"+par1TextArea.getText().replaceAll("\n", "<br>")+"</p>\n";
        if (parNumCombo.getSelectedIndex()>=1)
            html += "<p class=\"ajax-font\">"+par2TextArea.getText().replaceAll("\n", "<br>")+"</p>\n";
        if (parNumCombo.getSelectedIndex()>=2)
            html += "<p class=\"ajax-font\">"+par3TextArea.getText().replaceAll("\n", "<br>")+"</p>\n";
        html += "</div>\n" +
                "</body>\n" +
                "</html>\n";
        saveHtml(html);
    }
    
    private void saveHtml(String html) {
        /*
        This method save the html string inside a file named: pageN.html, with 
        N = last number of page added. With this rule we will be able to find the last 
        page added and continue adding pages from that.
        */
        try {
            File file = new File("emptyCourse/content/contents/page"
                    +(principale.lastNumberAdded+1)
                    +".html");
            FileWriter fw = new FileWriter(file);
            fw.write(html);
            fw.flush();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void updateSecCombo(char added, boolean setup) {
        /*
        This method manages the combobox that shows the section where the user can
        add a page.
        The combobox has to "guide" and force the user to follow the selection I-P-A-R-F:
        I = the user needs to add at least one introduction page
        P = the user needs to add at least one question in the pre-test
        A = the user needs to add at least one content page
        R = the user needs to add at least one summary page
        F = the user needs to add at least one question in the final test (score saved)
        */
        if (added != principale.lastSectionAdded || setup) {
            secCombo.removeAllItems();
            if (added == '0') {
                secCombo.addItem("Introduction");
            }
            if (added == 'I') {
                secCombo.addItem("Introduction");
                secCombo.addItem("Pre-test");
            }
            if (added == 'P') {  //the user needs to add at least one content page
                secCombo.addItem("Content");
            }
            if (added == 'A') {
                secCombo.addItem("Content");
                secCombo.addItem("Summary");
            }
            if (added == 'R') {
                secCombo.addItem("Summary");
                secCombo.addItem("Final test");
            }
            principale.lastSectionAdded = added;
        }
    }
    
    private char getSectionSelected() {
        /*
        This method returns the code (I-P-A-R-F) depending on the user selection.
        */
        String section = secCombo.getSelectedItem().toString();
        switch (section) {
            case "Introduction":    return 'I';
            case "Pre-test":        return 'P';
            case "Content":         return 'A';
            case "Summary":         return 'R';
            case "Final test":      return 'F';
        }
        return '0';
    }
    
    private void createJS() {
        /*
        This method updates the pages.js buffer.
        */
        if (!quiz) { //if the user didn't choose to add a test
            if (principale.lastSectionAdded == '0') { 
                /*
                New buffer created, because no page is present in the section.
                */
                principale.buffer.setLength(0);
                principale.buffer.append("$(document).ready(function(e) {"
                        + "\npages["
                        +(principale.lastNumberAdded+1)
                        +"] = new page(\"contents/page"
                        +(principale.lastNumberAdded+1)
                        +".html\",\""
                        + getSectionSelected()
                        + "\",\""
                        + titleField.getText() 
                        + "\",false, false);\n");
            }
            else { //Adding a new page to the buffer
                principale.buffer.append("pages["
                        + (principale.lastNumberAdded+1)
                        + "] = new page(\"contents/page"
                        + (principale.lastNumberAdded+1)
                        + ".html\",\""
                        + getSectionSelected()
                        + "\",\""
                        + titleField.getText()
                        + "\",false, false);\n");
            }
        } else { //in case the user selected a test
            principale.buffer.append("pages["
                    + (principale.lastNumberAdded + 1)
                    + "] = new page(\"contents/test.html\",\""
                    + getSectionSelected()
                    + "\",\"");
            if (getSectionSelected()=='P') {
                principale.buffer.append("Pre-test"); 
            } else {
                principale.buffer.append("Final test");
            }
            principale.buffer.append("\",false, false);\n");
            
        }
    }

    private boolean parsEmpty() { 
        /*
        This methods checks no paragraph is empty.
        */
        if (parNumCombo.getSelectedIndex()==0 && par1TextArea.getText().trim().isEmpty()) {
            return true;
        } 
        if (parNumCombo.getSelectedIndex()==1 && par2TextArea.getText().trim().isEmpty()) {
            return true;
        }
        if (parNumCombo.getSelectedIndex()==2 && par3TextArea.getText().trim().isEmpty()) {
            return true;
        }
        return false;
    }
    
    private void cleanFields() {
        titleField.setText(null);
        par1TextArea.setText(null);
        par2TextArea.setText(null);
        par3TextArea.setText(null);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        titleField = new javax.swing.JTextField();
        par1Label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        par1TextArea = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        par2TextArea = new javax.swing.JTextArea();
        par2Label = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        par3TextArea = new javax.swing.JTextArea();
        par3Label = new javax.swing.JLabel();
        parNumberLabel = new javax.swing.JLabel();
        parNumCombo = new javax.swing.JComboBox();
        secLabel = new javax.swing.JLabel();
        secCombo = new javax.swing.JComboBox();
        compTimeLabel = new javax.swing.JLabel();
        compTime = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        export = new javax.swing.JButton();
        addAnimation = new javax.swing.JCheckBox();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Create text page");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setText("*Page title:");

        par1Label.setText("*Paragraph 1:");

        par1TextArea.setColumns(20);
        par1TextArea.setLineWrap(true);
        par1TextArea.setRows(5);
        jScrollPane1.setViewportView(par1TextArea);

        par2TextArea.setColumns(20);
        par2TextArea.setLineWrap(true);
        par2TextArea.setRows(5);
        jScrollPane2.setViewportView(par2TextArea);

        par2Label.setText("*Paragraph 2:");

        par3TextArea.setColumns(20);
        par3TextArea.setLineWrap(true);
        par3TextArea.setRows(5);
        par3TextArea.setEnabled(false);
        jScrollPane3.setViewportView(par3TextArea);

        par3Label.setText("*Paragraph 3:");
        par3Label.setEnabled(false);

        parNumberLabel.setText("*Number of paragraphs:");

        parNumCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3" }));
        parNumCombo.setSelectedIndex(1);
        parNumCombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                parNumComboItemStateChanged(evt);
            }
        });

        secLabel.setText("*Course section:");

        secCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Introduzione" }));

        compTimeLabel.setText("Minimum time required on page:");

        compTime.setModel(new javax.swing.SpinnerNumberModel(0, 0, 20, 1));
        compTime.setEditor(new javax.swing.JSpinner.NumberEditor(compTime, ""));

        jLabel2.setText("seconds");

        jLabel3.setFont(new java.awt.Font("Lucida Fax", 0, 8)); // NOI18N
        jLabel3.setText("Recommended max 400 words total.");

        jLayeredPane1.setLayout(new java.awt.FlowLayout());

        export.setText("Add page to course");
        export.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportActionPerformed(evt);
            }
        });
        jLayeredPane1.add(export);

        addAnimation.setSelected(true);
        addAnimation.setText("Add animation");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("* required fields");

        jLabel4.setFont(new java.awt.Font("Lucida Fax", 0, 8)); // NOI18N
        jLabel4.setText("Recommended max 30 characters.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(titleField)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(compTimeLabel)
                                    .addComponent(parNumberLabel))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(17, 17, 17)
                                        .addComponent(parNumCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(compTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel2))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(secLabel)
                                .addGap(25, 25, 25)
                                .addComponent(secCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(par1Label)
                            .addComponent(addAnimation))
                        .addGap(0, 199, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(par3Label)
                            .addComponent(par2Label))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2)
                            .addComponent(jScrollPane3))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(secLabel)
                    .addComponent(secCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(compTimeLabel)
                    .addComponent(compTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(parNumberLabel)
                    .addComponent(parNumCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(par1Label)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(par3Label)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(addAnimation)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addComponent(par2Label))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        /*
        When this framed is closed, we return to the main frame.
        */
        principale.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void exportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportActionPerformed
        /*
        The user clicked the button to add the page to the course.
        */
        if (!quiz) {
            /*
            In case the user isn't adding a test, we check all the info is correct
            */
            if (titleField.getText().trim().isEmpty() || parsEmpty()) {
                JOptionPane.showMessageDialog(this, "Please complete all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                createHtml(); //html page building
                createJS(); //buffer update
                JOptionPane.showMessageDialog(this, "Page added to section -"
                        +secCombo.getSelectedItem().toString()
                        +"-", "Message", JOptionPane.INFORMATION_MESSAGE);
                principale.lastNumberAdded++; //new page number
                updateSecCombo(getSectionSelected(), false); //combobox update
                cleanFields(); 
            }
        } else {
            /*
            If the user wants to add a pre-test or final test, we create a Quiz 
            object, which will be used to manage the test questions and answers.
            */
            Quiz q = new Quiz(getSectionSelected(), this, principale);
            this.setVisible(false);
            q.setVisible(true);
            createJS();
            principale.lastNumberAdded++;
            updateSecCombo(getSectionSelected(), false); //aggiornamento combobox
        }
    }//GEN-LAST:event_exportActionPerformed

    private void parNumComboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_parNumComboItemStateChanged
        /*
        The number of paragraph can change between 1 and 3.
        */
        switch (parNumCombo.getSelectedIndex()) {
            case 0: //one paragraph
                par2TextArea.setEnabled(false);
                par2Label.setEnabled(false);
                par3TextArea.setEnabled(false);
                par3Label.setEnabled(false);
                break;
            case 1: //two paragraphs
                par2TextArea.setEnabled(true);
                par2Label.setEnabled(true);
                par3TextArea.setEnabled(false);
                par3Label.setEnabled(false);
                break;
            case 2: //three paragraphs
                par2TextArea.setEnabled(true);
                par2Label.setEnabled(true);
                par3TextArea.setEnabled(true);
                par3Label.setEnabled(true);
                break;
        }
        
    }//GEN-LAST:event_parNumComboItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TextPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TextPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TextPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TextPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TextPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox addAnimation;
    private javax.swing.JSpinner compTime;
    private javax.swing.JLabel compTimeLabel;
    private javax.swing.JButton export;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel par1Label;
    private javax.swing.JTextArea par1TextArea;
    private javax.swing.JLabel par2Label;
    private javax.swing.JTextArea par2TextArea;
    private javax.swing.JLabel par3Label;
    private javax.swing.JTextArea par3TextArea;
    private javax.swing.JComboBox parNumCombo;
    private javax.swing.JLabel parNumberLabel;
    private javax.swing.JComboBox secCombo;
    private javax.swing.JLabel secLabel;
    private javax.swing.JTextField titleField;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            /*
            If the user selects test from the combobox, all the fields are disabled,
            except the button that calls the test frame.
            */
            if (((JComboBox) e.getSource()).getSelectedItem().equals("Final test")
                    || ((JComboBox) e.getSource()).getSelectedItem().equals("Pre-test")) {
                cleanFields();
                titleField.setEnabled(false);
                compTime.setEnabled(false);
                parNumCombo.setEnabled(false);
                par1TextArea.setEnabled(false);
                par2TextArea.setEnabled(false);
                par3TextArea.setEnabled(false);
                par1Label.setEnabled(false);
                par2Label.setEnabled(false);
                par3Label.setEnabled(false);
                addAnimation.setEnabled(false);
                quiz = true;
            } else {
                if (!titleField.isEnabled()) {
                    titleField.setEnabled(true);
                    compTime.setEnabled(true);
                    par1Label.setEnabled(true);
                    par1TextArea.setEnabled(true);
                    parNumCombo.setEnabled(true);
                    parNumCombo.setSelectedIndex(0);
                    parNumCombo.setSelectedIndex(1);
                    addAnimation.setEnabled(true);
                    quiz = false;
                }
            }
        } catch (Exception ex) {
        }
    }
}
