$(document).ready(function(e) {
pages[0] = new page("page0.html","I","dcsd",false, false);
pages[1] = new page("page1.html","P","sdvc",false, false);
pages[2] = new page("page2.html","A","sdcsd",false, false);
pages[3] = new page("page3.html","R","csd",false, false);
pages[4] = new page("page4.html","F","cs",false, false);
});