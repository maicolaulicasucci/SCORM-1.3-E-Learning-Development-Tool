$(document).ready(function(e) {
questionsF[0] = new question("Q2","0","?", "right", "no", "no", "no");
});