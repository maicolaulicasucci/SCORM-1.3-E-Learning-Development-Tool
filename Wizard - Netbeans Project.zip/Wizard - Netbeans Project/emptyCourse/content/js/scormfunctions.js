/*
Source code created by Rustici Software, LLC is licensed under a 
Creative Commons Attribution 3.0 United States License
(http://creativecommons.org/licenses/by/3.0/us/)

Want to make SCORM easy? See our solutions at http://www.scorm.com.

This example demonstrates the use of basic runtime calls in a multi-page SCO. It
includes a demonstration of bookmarking, status reporting (completion and success), 
score and time. It also includes the addition of a basic "controller" for providing
intra-SCO navigation.
*/


//Include the standard ADL-supplied API discovery algorithm


///////////////////////////////////////////
//Begin ADL-provided API discovery algorithm
///////////////////////////////////////////

var nFindAPITries = 0;
var API = null;
var maxTries = 500; 


//La funzione ScanForApi() cerca un oggetto di nome API_1484_11 nella finestra
//che � passata come parametro. Se l'oggetto viene trovato, ritorna il puntatore 
//all'oggetto. Se viene trovata l'istanza, lo SCO adesso pu� dialogare con 
//l'LMS tramite API Instance. La funzione trova il massimo numero di padri
//della finestra corrente. Se non si trova nessun oggetto, si ritorna null.
//Questa funzione inoltre riassegna un valore alla finestra passata come parametro,
//in base al numero di padri. Alla fine della funzione, la variabile win sar�
//assegnata al padre di livello pi� alto tra tutti i disponibili.
function ScanForAPI(win)
{
   while ((win.API_1484_11 == null) && (win.parent != null) 
           && (win.parent != win))
   {
		 //si rimane nel while finch� non si trova l'istanza, finch� ci sono padri e 
		 //finch� il padre non � la finestra stessa
      nFindAPITries++;
      if (nFindAPITries > maxTries)
      {
         return null;
      }
      win = win.parent; //passo al frame superiore, risalgo la gerarchia dei frame
   }
   return win.API_1484_11;
} 


/*
La funzione GetAPI() inizia il processo di ricerca dell'istanza API del
LMS. La funzione riceve un parametro che rappresenta la finestra corrente.
La funzione � costruita per ricercare in un ordine specifico e fermarsi quando
si trova l'API wrapper. La funzione parte con il ricercare il padre della 
finestra corrente, se ovviamente � presente. Se l'istanza API non � trovata,
la funzione controlla se ci sono altre finestre aperte tipo popup. Se la finestra 
� aperta in un'altra finestra, la funzione inizia a cercare l'istanza API 
nel popup.
*/
function GetAPI(win)
{
   if ((win.parent != null) && (win.parent != win))
   {
      API = ScanForAPI(win.parent); //cerco fuori dagli iFrame
   }
   if ((API == null) && (win.opener != null))
   {
      API = ScanForAPI(win.opener); //cerco nel popup
   }
}

///////////////////////////////////////////
//End ADL-provided API discovery algorithm
///////////////////////////////////////////
  
  
//Creazione funzioni che gestiscono il caricamento/scaricamento della pagina

//Constants
var SCORM_TRUE = "true";
var SCORM_FALSE = "false";
var SCORM_NO_ERROR = "0";

//Visto che il gestore Unload sar� chiamato 2 volte, sia fagli eventi onunload
//e onbeforeunload, assicurarsi che si chiami la terminazione solo una volta.
var terminateCalled = false;

//Tracciamento inizializzazione.
var initialized = false;

function ScormProcessInitialize(){
    var result;
    
    GetAPI(window); //richiama la ricerca API
    
    if (API == null){  //API � una variabile globale
        alert("ERRORE - Non � possibile stabilire una connessione con LMS\n\nI tuoi risultati potrebbero non essere salvati.");
        return;
    }
    
    result = API.Initialize(""); //Inizializzazione come da standard
    
    if (result == SCORM_FALSE){ //Caso di errore
        var errorNumber = API.GetLastError();
        var errorString = API.GetErrorString(errorNumber);
        var diagnostic = API.GetDiagnostic(errorNumber);
        
        var errorDescription = "Numero: " + errorNumber + "\nDescrizione: " + errorString + "\nDiagnostica: " + diagnostic;
        
        alert("ERRORE - Non � possibile iniziale correttamente una comunicazione con LMS.\n\nI tuoi risultati potrebbero non essere salvati.\n\n" + errorDescription);
        return;
    }
    
    initialized = true;
}

function ScormProcessTerminate(){
    
    var result;
    
		//Non si termina se non abbiamo ancora inizializzato o se � gi� terminato
    if (initialized == false || terminateCalled == true){return;}
    
    result = API.Terminate(""); //terminazione come da standard
    
    terminateCalled = true;
    
    if (result == SCORM_FALSE){ //gestione errori
        var errorNumber = API.GetLastError();
        var errorString = API.GetErrorString(errorNumber);
        var diagnostic = API.GetDiagnostic(errorNumber);
        
        var errorDescription = "Numero: " + errorNumber + "\nDescrizione: " + errorString + "\nDiagnostica: " + diagnostic;
        
        alert("ERRORE - Non � possibile terminare correttamente la comunicazione con LMS.\n\nI tuoi risultati potrebbero non essere salvati.\n\n" + errorDescription);
        return;
    }
}


/*
I gestori degli eventi onload e onunload sono assegnati in launchpage.html perch� pi� processi potrebbero
accedere diverse volte.
*/
//window.onload = ScormProcessInitialize;
//window.onunload = ScormProcessTerminate;
//window.onbeforeunload = ScormProcessTerminate;

//Ci sono casi in cui la chiamata GetValue genera errori, e non si deve informare l'utente
function ScormProcessGetValue(element, checkError){
    
    var result;
    
    if (initialized == false || terminateCalled == true){return;} //controllo comunicazione corretta con LMS
    
    result = API.GetValue(element);
    
    if (checkError == true && result == ""){  //Se si entra qui vuol dire che c'� un errore
    
        var errorNumber = API.GetLastError();
        
        if (errorNumber != SCORM_NO_ERROR){
            var errorString = API.GetErrorString(errorNumber);
            var diagnostic = API.GetDiagnostic(errorNumber);
            
            var errorDescription = "Numero: " + errorNumber + "\nDescrizione: " + errorString + "\nDiagnostica: " + diagnostic;
            
            alert("ERRORE - Non � possibile ricevere il valore da LMS.\n\n" + errorDescription);
            return "";
        }
    }
    
    return result;
}

function ScormProcessSetValue(element, value){
   
    var result;
    
    if (initialized == false || terminateCalled == true){return;}
    
    result = API.SetValue(element, value);
    
    if (result == SCORM_FALSE){
        var errorNumber = API.GetLastError();
        var errorString = API.GetErrorString(errorNumber);
        var diagnostic = API.GetDiagnostic(errorNumber);
        
        var errorDescription = "Numero: " + errorNumber + "\nDescrizione: " + errorString + "\nDiagnostica: " + diagnostic + "\nCausa: " + element;
        
        alert("ERRORE - Non � possibile salvare il valore nel LMS.\n\nI tuoi risultati potrebbero non essere salvati.\n\n" + errorDescription);
        return;
    }
    
}

function ScormProcessCommit(){
    
    var result;
    
    result = API.Commit("");
    
    if (result == SCORM_FALSE){
        var errorNumber = API.GetLastError();
        var errorString = API.GetErrorString(errorNumber);
        var diagnostic = API.GetDiagnostic(errorNumber);
        
        var errorDescription = "Numero: " + errorNumber + "\nDescrizione: " + errorString + "\nDiagnostica: " + diagnostic;
        
        alert("Errore - Non � possibile invocare il comando Commit.\n\nI Tuoi risultati potrebbero non essere salvati.\n\n" + errorDescription);
        return;
    }
}

//SCORM requires time to be formatted in a specific way
function ConvertMilliSecondsIntoSCORM2004Time(intTotalMilliseconds){

	var ScormTime = "";
	
	var HundredthsOfASecond;	//decrementing counter - work at the hundreths of a second level because that is all the precision that is required
	
	var Seconds;	// 100 hundreths of a seconds
	var Minutes;	// 60 seconds
	var Hours;		// 60 minutes
	var Days;		// 24 hours
	var Months;		// assumed to be an "average" month (figures a leap year every 4 years) = ((365*4) + 1) / 48 days - 30.4375 days per month
	var Years;		// assumed to be 12 "average" months
	
	var HUNDREDTHS_PER_SECOND = 100;
	var HUNDREDTHS_PER_MINUTE = HUNDREDTHS_PER_SECOND * 60;
	var HUNDREDTHS_PER_HOUR   = HUNDREDTHS_PER_MINUTE * 60;
	var HUNDREDTHS_PER_DAY    = HUNDREDTHS_PER_HOUR * 24;
	var HUNDREDTHS_PER_MONTH  = HUNDREDTHS_PER_DAY * (((365 * 4) + 1) / 48);
	var HUNDREDTHS_PER_YEAR   = HUNDREDTHS_PER_MONTH * 12;
	
	HundredthsOfASecond = Math.floor(intTotalMilliseconds / 10);
	
	Years = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_YEAR);
	HundredthsOfASecond -= (Years * HUNDREDTHS_PER_YEAR);
	
	Months = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_MONTH);
	HundredthsOfASecond -= (Months * HUNDREDTHS_PER_MONTH);
	
	Days = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_DAY);
	HundredthsOfASecond -= (Days * HUNDREDTHS_PER_DAY);
	
	Hours = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_HOUR);
	HundredthsOfASecond -= (Hours * HUNDREDTHS_PER_HOUR);
	
	Minutes = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_MINUTE);
	HundredthsOfASecond -= (Minutes * HUNDREDTHS_PER_MINUTE);
	
	Seconds = Math.floor(HundredthsOfASecond / HUNDREDTHS_PER_SECOND);
	HundredthsOfASecond -= (Seconds * HUNDREDTHS_PER_SECOND);
	
	if (Years > 0) {
		ScormTime += Years + "Y";
	}
	if (Months > 0){
		ScormTime += Months + "M";
	}
	if (Days > 0){
		ScormTime += Days + "D";
	}
	
	//check to see if we have any time before adding the "T"
	if ((HundredthsOfASecond + Seconds + Minutes + Hours) > 0 ){
		
		ScormTime += "T";
		
		if (Hours > 0){
			ScormTime += Hours + "H";
		}
		
		if (Minutes > 0){
			ScormTime += Minutes + "M";
		}
		
		if ((HundredthsOfASecond + Seconds) > 0){
			ScormTime += Seconds;
			
			if (HundredthsOfASecond > 0){
				ScormTime += "." + HundredthsOfASecond;
			}
			
			ScormTime += "S";
		}
		
	}
	
	if (ScormTime == ""){
		ScormTime = "0S";
	}
	
	ScormTime = "P" + ScormTime;
	
	return ScormTime;
}