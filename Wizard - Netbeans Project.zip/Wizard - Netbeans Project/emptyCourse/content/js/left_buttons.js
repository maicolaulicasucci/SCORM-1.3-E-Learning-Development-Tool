// Gestione pulsanti laterali
$(document).ready(function() {
	//init references
	$(".link-win").removeClass("bold"); //rimuovo a tutti bold
	$("#linkography").addClass("bold");
	$("#references-win .content-win").load("contents/plus/linkography.html");
		
	$("#references").on("click",function(e) {
	if ($("#glossary-win").is(":visible")) {
			$.when($("#glossary-win").not(":animated")).then($("#references-win").delay(100).fadeToggle("fast")); //per non fa sovrapporre 
		} else {
			if ($("#help-win").is(":visible")) {
				$.when($("#help-win").is(":animated")).then($("#references-win").delay(100).fadeToggle("fast"));
			} else {
				$("#references-win").fadeToggle("fast");
			}
		}
	});
	$("#linkography").on("click", function(e) {
		if (!$("#linkography").hasClass("bold")){
			$(".link-win").removeClass("bold");
			$("#linkography").addClass("bold");
			$("#references-win .content-win").load("contents/plus/linkography.html");
		}
	});
	$("#credits").on("click",function(e) {
		if (!$("#credits").hasClass("bold")){
			$(".link-win").removeClass("bold");
			$("#credits").addClass("bold");
			$("#references-win .content-win").load("contents/plus/credits.html");
		}
	});
	
	//init Glossary
	initGlossary();
	$("#glossary").on("click",function(e) {
		if ($("#references-win").is(":visible")) {
			$.when($("#references-win").is(":animated")).then($("#glossary-win").delay(100).fadeToggle("fast"));
		} else {
			if ($("#help-win").is(":visible")) {
				$.when($("#help-win").is(":animated")).then($("#glossary-win").delay(100).fadeToggle("fast"));
			} else {
				$("#glossary-win").fadeToggle("fast");
			}
		}
	});
	
	//init help
	initHelp();
	$("#help").on("click",function(e) {
		if ($("#references-win").is(":visible")) {
			$.when($("#references-win").is(":animated")).then($("#help-win").delay(100).fadeToggle("fast"));
		} else {
			if ($("#glossary-win").is(":visible")) {
				$.when($("#glossary-win").is(":animated")).then($("#help-win").delay(100).fadeToggle("fast"));
			} else {
				$("#help-win").fadeToggle("fast");
			}
		}
	});
	$("#heading").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/heading.html");
	});
	$("#help-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/help.html");
	});
	$("#glossary-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/glossary.html");
	});
	$("#references-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/references.html");
	});
	$("#player-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/player.html");
	});
	$("#navigation-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/navigation.html");
	});
	$("#video-h").on("click", function(e) {
			$(".content-win-mod-help").load("contents/plus/video.html");
	});
	
	//Chiusura riferimenti con click sulla pagina
	$(document).on("mousedown", function(e) {  
		var ref = $("#references-win");
		if (ref.is(":visible") && !$(e.target).closest('#references-win').length && !$(e.target).closest('#references').length) {
				ref.fadeOut("fast");
		}
		var glo = $("#glossary-win");
		if (glo.is(":visible") && !$(e.target).closest('#glossary-win').length && !$(e.target).closest('#glossary').length) {
				glo.fadeOut("fast");
		}
		var hel = $("#help-win");
		if (hel.is(":visible") && !$(e.target).closest('#help-win').length && !$(e.target).closest('#help').length) {
				hel.fadeOut("fast");
		}
	});
});


function initGlossary() {
  $('#cssglossary > ul > li:has(ul)').addClass("has-sub");

  $('#cssglossary > ul > li > a').click(function() {
    var checkElement = $(this).next();
    
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) { //Se ci sono altri sottomenu aperti, li chiudo
      checkElement.slideUp('normal');
    } 
    else {
			if((checkElement.is('ul')) && (!checkElement.is(':visible'))) { //Se il sottomenu cliccato non è visibile lo apro
				$('#cssglossary ul ul:visible').slideUp('normal');
				checkElement.slideDown('normal');
			}
			else {
				$('#cssglossary ul ul:visible').slideUp('normal'); //Se entro qui vuol dire che ho cliccato un link senza sottomenu
			}
		}
			
    
    if (checkElement.is('ul')) {
      return false;
    } else {
      return true;	
    }		
  });

}

function initHelp() {
  $('#csshelp > ul > li:has(ul)').addClass("has-sub");

  $('#csshelp > ul > li > a').click(function() {
    var checkElement = $(this).next();
    
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) { //Se ci sono altri sottomenu aperti, li chiudo
      checkElement.slideUp('normal');
    } 
    else {
			if((checkElement.is('ul')) && (!checkElement.is(':visible'))) { //Se il sottomenu cliccato non è visibile lo apro
				$('#csshelp ul ul:visible').slideUp('normal');
				checkElement.slideDown('normal');
			}
			else {
				$('#csshelp ul ul:visible').slideUp('normal'); //Se entro qui vuol dire che ho cliccato un link senza sottomenu
			}
		}
			
    
    if (checkElement.is('ul')) {
      return false;
    } else {
      return true;	
    }		
  });

}
