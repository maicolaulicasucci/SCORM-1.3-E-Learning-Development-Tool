// Gestione video

$(document).ready(function(){
	
	//Chiusura barra volume con click sulla pagina
	$(document).on("mousedown", function(e) {  
		var vol = $(".slider_vol");
		if (vol.is(":visible") && !$(e.target).closest('.slider_vol').length && !$(e.target).closest('#volume').length) {
				vol.fadeOut(300);
		}
	});
	
});

function getVideo(address, section) {

	//INIZIALIZZAZIONE
	var video = null;
	if (!$("#play_pause").hasClass("playh")) { //se vero vuol dire che la pagina precedente era senza video
		$("#play_pause").addClass("playh");
		$("#comment").addClass("commenth");
		$("#volume").addClass("volumeh");
		
		$("#volume").on("click", function(e) { //riattivo il tasto volume
			$(".slider_vol").fadeToggle(300);
		});
	}
	
	$("#content").html("Loading...").load(address, function(result) {
		video = $('#content #video_cont #myVideo');
		
		//Aggiorno titolo e sottotitolo
		var subtitle = $("#content title").text();
		$("header #mainTitle").text(getSectionFromS(section));
		$("header #mainSubtitle").text(subtitle);
		
		//Play/pause
		$("#play_pause").on("click", function() {
			if (video[0].paused) {
				video[0].play();
				$("#play_pause").removeClass("play").removeClass("playh").addClass("pause").addClass("pauseh");
			}
			else {
				video[0].pause();
				$("#play_pause").removeClass("pause").removeClass("pauseh").addClass("play").addClass("playh");
			}
			return false;
		});
			
		//Leggo la durata del video HTML5 e la setto sullo span
		video.on("loadedmetadata", function() {
			$('#currentTime').text(timeFormat(0));
			$("#duration").text(timeFormat(video[0].duration));
		});
		
		//Leggo l'istante corrente del video HTML5 e lo setto sullo span
		video.on("timeupdate", function() {
			var currentPos=video[0].currentTime; //get currentTime
			var maxduration=video[0].duration; //get videoDuration
			var percentage= 100 * (currentPos/maxduration); 
			$("#sliderTime").css("width",percentage+"%"); //vario la % di completamento
			$('#currentTime').text(timeFormat(currentPos));
		});
		
		//Evento video finito
		video.on('ended', function() {
			$("#play_pause").removeClass("pause").removeClass("pauseh").addClass("play").addClass("playh");
			video[0].pause();
		});
		
		//VIDEO PROGRESS BAR
		//Gestione click sulla barra
		var timeDrag = false;	/* check for drag event */
		$('.slider').on('mousedown', function(e) {
			timeDrag = true;
			updatebar(e.pageX);
		});
		$(document).on('mouseup', function(e) {
			if(timeDrag) {
				timeDrag = false;
				updatebar(e.pageX);
			}
		});
		$(document).on('mousemove', function(e) {
			if(timeDrag) {
				updatebar(e.pageX);
			}
		});
		var updatebar = function(x) {
			var progress = $('.slider');
			
			//Calcolo la posizione del primo click
			//e aggiorno il tempo corrente del video
			//e la progress bar
			var maxduration = video[0].duration;
			var position = x - progress.offset().left;
			var percentage = 100 * position / progress.width();
			if(percentage > 100) {
				percentage = 100;
			}
			if(percentage < 0) {
				percentage = 0;
			}
			$('#sliderTime').css('width',percentage+'%');	
			video[0].currentTime = maxduration * percentage / 100;
		};
		
		//Imposto il volume del video attuale come quello del video precedente
		var positionPrev = $('#volume_hover').css('height').replace("px",""); //valore precedente del volume, la prima volta è al max
		percentagePrev = 100 * positionPrev / ($("#volume_hover").css("max-height").replace("px",""));
		//Aggiorno la barra del volume e il volume del video
		video[0].volume = percentagePrev / 100;
		
		//Barra del volume
		var volumeDrag = false;
		$('.slider_vol').on('mousedown', function(e) {
			volumeDrag = true;
			video[0].muted = false;
			updateVolume(e.pageY);
		});
		$(document).on('mouseup', function(e) {
			if(volumeDrag) {
				volumeDrag = false;
				updateVolume(e.pageY);
			}
		});
		$(document).on('mousemove', function(e) {
			if(volumeDrag) {
				updateVolume(e.pageY);
			}
		});
		var updateVolume = function(y) {
			var volume = $('#volume_base');
			var percentage;
			var position = (volume.offset().top+volume.height()) - y - 15; //offset().bottom non funziona, 15 è il bottom di vol_hover
			
			if (position<0) {
				position=0;
			} else {
				if (position>0 && position<=20) {
					position=20;
				} else {
					if (position>20 && position<=35) {
						position=35;
					} else {
						if (position>35 && position<=50) {
							position=50;
						} else {
							if (position>50 && position<=65) {
								position=65;
							} else {
								if (position>65) {
									position=80;
								}
							}
						}
					}
				}
			}
			
			percentage = 100 * position / ($("#volume_hover").css("max-height").replace("px",""));
			//Aggiorno la barra del volume e il volume del video
			$('#volume_hover').css('height',position+'px');	
			video[0].volume = percentage / 100;
			
		};
		
	});
		
}

//Funzione trasformazione tempo
var timeFormat = function(seconds){
	var m = Math.floor(seconds/60)<10 ? "0"+Math.floor(seconds/60) : Math.floor(seconds/60);
	var s = Math.floor(seconds-(m*60))<10 ? "0"+Math.floor(seconds-(m*60)) : Math.floor(seconds-(m*60));
	return m+":"+s;
};

//Funzione che ripulisce tutti i comandi video quando cambio pagina
function cleanVideoCommand() {
	var video = $('#content #video_cont #myVideo'); //riferimento al video precedente
	
	if (video.length>0) { //Ripulisco solo se la pagina precedente conteneva un video
		$("#play_pause").unbind("click"); //relativo al pulsante play
		video.unbind("loadmetadata"); //relativo ai tempi del video
		video.unbind("timeupdate"); //relativo al tempo corrente del video
		video.unbind("ended"); //fine del video
		$(".slider").unbind("mousedown"); //progress bar scorrimento video
		$(document).unbind("mouseup"); //rilascio pulsante mouse
		$(document).unbind("mousemove"); //trascinamento mouse
		$('.slider_vol').unbind("mousedown"); //click sullo slider del volume
		$("#sliderTime").css("width","0%"); //azzero la barra dello scorrimento

		$("#play_pause").removeClass("pause").removeClass("pauseh").addClass("play").addClass("playh"); //rimetto il pulsante su play
		
	}
}