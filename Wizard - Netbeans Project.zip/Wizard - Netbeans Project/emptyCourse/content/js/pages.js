$(document).ready(function(e) {
pages[0] = new page("contents/page0.html","I","Intro1",false, false);
pages[1] = new page("contents/test.html","P","Pre-test",false, false);
pages[2] = new page("contents/page2.html","A","Im1",false, false);
pages[3] = new page("contents/page3.html","R","Summary",false, false);
pages[4] = new page("contents/test.html","F","Final test",false, false);
});