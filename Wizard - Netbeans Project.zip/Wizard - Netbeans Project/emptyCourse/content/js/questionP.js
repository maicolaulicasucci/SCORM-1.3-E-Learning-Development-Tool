$(document).ready(function(e) {
questionsP[0] = new question("Q1","0","?", "Right", "no", "no", "no");
});