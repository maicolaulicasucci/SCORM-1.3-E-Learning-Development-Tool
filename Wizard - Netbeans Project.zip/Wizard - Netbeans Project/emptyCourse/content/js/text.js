// Gestione pagine di testo

function getText(address,section) {
	
	if ($("#play_pause").hasClass("playh")) { //se vero vuol dire che la pagina precedente era con video
		$("#play_pause").removeClass("playh");
		$("#comment").removeClass("commenth");
		$("#volume").removeClass("volumeh");
		$("#volume").unbind("click");
		$("#duration").text(timeFormat(0));
		$("#currentTime").text(timeFormat(0));
	}
	
	$("#content").html("Loading...").load(address, function(result){
		//Aggiorno titolo e sottotitolo
		$("header #mainTitle").text(getSectionFromS(section));
		if (section!="P" && section!="F") {
			var subtitle = $("#content title").text();
			$("header #mainSubtitle").text(subtitle);
		} else {
			$("header #mainSubtitle").text("");
			if (section=="P") {
				welcomeQuiz("P");
			} else {
				welcomeQuiz("F");
			}
		}
	});
}
