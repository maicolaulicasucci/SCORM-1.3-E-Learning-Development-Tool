// Gestione navigazione

//INIZIALIZZAZIONE
var currentPage = null;
var startTimeStamp = null;
var pages = new Array();
//Le variabili successive mi servono per automatizzare l'apertura della sezione corrispondente alla pagina visitata
var numI = 0; //Numero di pagine nell'introduzione
var numA = 0; //Numero di pagine negli argomenti
var numR = 0; //Numero di pagine nel riepilogo
var numP = 0; //Questo al max è 1 --> per far funzionare l'apertura automatica della sezione giusta si devono inserire i pretest
var numF = 0; //Come sopra

//Costruttore pagine
function page(address, section, menuTitle, video, completed) {
	this.address = address;
	this.section = section;
	this.menuTitle = menuTitle;
	this.video = video;
	this.completed = completed;
}

$(document).ready(function(e) {

	countPages();
	
	//si memorizza l'ora in cui lo studente inizia lo SCO in modo da poter calcolare il tempo impiegato
	startTimeStamp = new Date();
	//si inizializza la comunicazione con LMS
	ScormProcessInitialize();
	
	//è buona pratica settare il completion_status a incomplete se è la prima volta che si
	//lancia il corso (ovviamente se il corso non è stato già completato)
	var completionStatus = ScormProcessGetValue("cmi.completion_status", true); //si legge il vecchio valore, con controlloErr
	if (completionStatus == "unknown"){ //prima volta che si entra!
		ScormProcessSetValue("cmi.completion_status", "incomplete");
	}
	
	//Si controlla se l'utente ha salvato il bookmark in precedenza (non si controlla l'errore
	//perchè cmi.location potrebbe non essere inizializzata!)
	var bookmark = ScormProcessGetValue("cmi.location", false);
	
	//se non c'è un bookmark salvato, si riparte dalla prima pagina
	if (bookmark == "" || bookmark == null){
		currentPage = 0;
	}
	else{
		//se c'è un bookmark salvato, si chiede all'utente di resumare dal punto in cui era rimasto
		if (confirm("Desideri partire da dove eri rimasto l'ultima volta?")){
			currentPage = parseInt(bookmark, 10);  
		}
		else{
			currentPage = 0;
		}
	}

	if (currentPage < numI) {  
		$("#introduction").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro introduzione
	} else {
		if (currentPage==numI) { //sono nei pretest
			$("#preTest").addClass("clicked").css("margin-left","15px"); //apro pretest
		} else {
			if (numI<=currentPage<=(pages.length-numA)) { 
				$("#arguments").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro argomenti
			} else {
				if (currentPage==pages.length) {
					$("#finalTest").addClass("clicked").css("margin-left","15px"); //apro test finali
				}
				else {
					$("#summary").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro riepilogo
				}
			}
		}
	}
	//gestione pagine completate
	var data = ScormProcessGetValue("cmi.suspend_data", false);
	//controllo se c'è salvato qualcosa
	//data="50|80|TTTTFFFFFFFFFFFFTT|"; //esempio di data
	if (data != null && data!="") {
		arg = data.split("|");
		if (arg[0]=="null") {
			scoreP=null;
		} else {
			scoreP=parseInt(arg[0]);
		}
		if (arg[1]=="null") {
			scoreF=null;
		} else {
			scoreF=parseInt(arg[1]);
		}
		for (var i=0; i<pages.length;i++) {
			if (arg[2][i]=="T") {
				pages[i].completed=true;
				if (pages[i].section=="P") { //pretest
					if (scoreP>60) {
						$("#preTest").children("span").addClass("passed");
					} else {
						$("#preTest").children("span").addClass("failed");
					}
				} else { 
					if (pages[i].section=="F") {//test finali
						if (scoreF>60) {
							$("#finalTest").children("span").addClass("passed");
						} else {
							$("#finalTest").children("span").addClass("failed");
						}
					} else { //pagina normale di contenuto
						$("#m"+i).addClass("completed");
					}
				}
			} else {
				pages[i].completed=false;
			}
		}
	}
	
	$("#currentPag").html(currentPage+1);
	$("#totPag").html(pages.length);
	if (currentPage==pages.length-1) {
		$("#next").removeClass("nexth");
	}
	if (currentPage==0) {
		$("#back").removeClass("backh");
	}

	if (pages[currentPage].video) {
		getVideo(pages[currentPage].address,pages[currentPage].section);		 //Carico la pagina
	}
	else {
		getText(pages[currentPage].address,pages[currentPage].section);
	} 
	
	$("#back").on("click", function() {
		if (currentPage!=0) {
			if (!pages[currentPage].completed && pages[currentPage].section!="P" && pages[currentPage].section!="F") { //se la pagina da cui si esce non è stata completata (non voglio mostrare i warning nei quiz), si mostra il warning
				if ($("#warning-win-next").is(":visible")) {
					$.when($("#warning-win-next").is(":animated")).then($("#warning-win-back").delay(100).fadeToggle("fast"));
				} else {
					$("#warning-win-back").fadeToggle("fast");
				}
			}			
			currentPage--;
			if (currentPage==(numI-1)) {  //vuol dire che sto tornando nell'introduzione
				$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
				$("#introduction").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro introduzione
			} else {
				if (currentPage==numI) {
					$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
					$("#preTest").addClass("clicked").css("margin-left","15px"); //apro pretest
				} else {
					if (currentPage==(pages.length-numR-numF-1)) {
						$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
						$("#arguments").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro gli argomenti
					} else {
						if (currentPage==(pages.length-numR-numF)) {
							$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
							$("#summary").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro gli riepilogo
						}
					}
				}
			}
			$("#currentPag").html(currentPage+1); //Aggiorno numero pagina
			if (currentPage==0 && $("#back").hasClass("backh")) {
					$("#back").removeClass("backh");
			} 
			if (!$("#next").hasClass("nexth")) {
				$("#next").addClass("nexth");
			}
			//RIPULITURA COMANDI VIDEO
			cleanVideoCommand();
			if (pages[currentPage].video) {
				getVideo(pages[currentPage].address,pages[currentPage].section);		
			}
			else {
				getText(pages[currentPage].address,pages[currentPage].section);
			}
		}
	});
	
	
	$("#next").on("click", function() {
		if (currentPage!=pages.length-1) {
			if (!pages[currentPage].completed && pages[currentPage].section!="P" && pages[currentPage].section!="F") { //se la pagina da cui si esce non è stata completata, si mostra il warning	
				if ($("#warning-win-back").is(":visible")) {
					$.when($("#warning-win-back").is(":animated")).then($("#warning-win-next").delay(100).fadeToggle("fast"));
				} else {
					$("#warning-win-next").fadeToggle("fast");
				}
			}
			currentPage++;
			if (currentPage==numI) {
				$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
				$("#preTest").addClass("clicked").css("margin-left","15px"); //apro pretest
			} else {
				if (currentPage==numI+numP) {  
					$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
					$("#arguments").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro argomenti
				} else {
					if (currentPage==(pages.length-numR-numF)) {  
						$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
						$("#summary").addClass("clicked").closest("li").addClass("active").children("a").css("margin-left","15px").next().slideDown(); //apro il riepilogo
					} else {
						if (currentPage==pages.length-numF) {
							$("#cssmenu > ul > li > a.clicked").removeClass("clicked").closest("li").removeClass("active").children("a").css("margin-left","0px").next().slideUp(); //nel caso sia cliccato qualcos'altro (quindi spostato), lo chiudo
						  $("#finalTest").addClass("clicked").css("margin-left","15px"); //apro il test finale
						}
					}
				}
			}
			$("#currentPag").html(currentPage+1); //Aggiorno numero pagina
			if (currentPage==pages.length-1 && $("#next").hasClass("nexth")) {
					$("#next").removeClass("nexth");
			} 
			if (!$("#back").hasClass("backh")) {
				$("#back").addClass("backh");
			}
			//RIPULITURA COMANDI VIDEO
			cleanVideoCommand();
			if (pages[currentPage].video) {
				getVideo(pages[currentPage].address,pages[currentPage].section);
			}
			else {
				getText(pages[currentPage].address,pages[currentPage].section);		
			}
		} else {
			if ($("#next").hasClass("nexth")) { //tolgo l'hover se sono alla prima pagina
				$("#next").removeClass("nexth");
			}
		}
	});
	
	$(".close-warning").on("click",function(e) {
		$(this).closest("div").fadeOut("fast");
	});
	
	$(document).on("mousedown", function(e) {    //chiusura warning se clicco fuori
		var war1 = $("#warning-win-next");
		if (war1.is(":visible") && !$(e.target).closest('#warning-win-next').length) {
				war1.fadeOut("fast");
		}
		var war2 = $("#warning-win-back");
		if (war2.is(":visible") && !$(e.target).closest('#warning-win-back').length) {
				war2.fadeOut("fast");
		}
	});
	
});

function goToPage(page) {
	/*
	Permetto di andare in una certa pagina solo se ho visitato fino almeno alla precedente (da chiarire)
	*/
	if (page!=currentPage) {  //vuol dire che voglio visitare una pagina diversa, quindi mi sposto
		currentPage=page;
		$("#currentPag").html(currentPage+1); //Aggiorno numero pagina
		if (currentPage==0 && $("#back").hasClass("backh")) {
			$("#back").removeClass("backh");
		} else {
			if (currentPage>0 && !$("#back").hasClass("backh")) {
				$("#back").addClass("backh");
			}
		}
		if (currentPage==pages.length-1 && $("#next").hasClass("nexth")) {
			$("#next").removeClass("nexth");
		}  else {
			if (currentPage<pages.length-1 && !$("#next").hasClass("nexth")) {
				$("#next").addClass("nexth");
			}
		}
		/*if (currentPage>1 && !$("#arguments").hasClass("clicked")) {  //vuol dire che sono tra gli argomenti
			$("#cssmenu > ul > li > a.clicked").trigger("click"); //nel caso sia cliccato qualcos'altro (quindi spostato)
			$("#cssmenu > ul > li > a#arguments").trigger("click");
		} else {
			if (!$("#arguments").hasClass("clicked")) {
				$("#cssmenu > ul > li > a.clicked").trigger("click"); //nel caso sia cliccato qualcos'altro (quindi spostato)
				$("#cssmenu > ul > li > a#introduction").trigger("click");
			}
		}*/
		//RIPULITURA COMANDI VIDEO
		cleanVideoCommand();
		if (pages[currentPage].video) {
			getVideo(pages[currentPage].address,pages[currentPage].section);		
		}
		else {
			getText(pages[currentPage].address,pages[currentPage].section);
		}
		$('#menu_hover').click(); //Chiudo il menu
	}
	
}

function unLoad() {  //viene richiamata all'uscita dal corso!
	//si salva la location attuale nel bookmark
	ScormProcessSetValue("cmi.location", currentPage);
	//si salva le altre informazioni nella suspend data
	data=scoreP+"|"; //salvo score pretest, se non è stato completato metto null
	data+=scoreF+"|"; //salvo score test finale, se non è stato completato metto null
	for (var i=0; i<pages.length;i++) { //salvo la lista delle pagine visitate
		if (pages[i].completed) {
			data+="T";
		} else {
			data+="F";
		}
	}
	data+="|";
	ScormProcessSetValue("cmi.suspend_data",data);
	
	var endTimeStamp = new Date();
	var totalMilliseconds = (endTimeStamp.getTime() - startTimeStamp.getTime());
	var scormTime = ConvertMilliSecondsIntoSCORM2004Time(totalMilliseconds);  //conversione tempo in formato SCORM2004
	
	ScormProcessSetValue("cmi.session_time", scormTime);
	
	//set exit to suspend
	ScormProcessSetValue("cmi.exit", "suspend");
	
	//issue a suspendAll navigation request
	ScormProcessSetValue("adl.nav.request", "suspendAll");
	
	ScormProcessTerminate();
}


function countPages() {  //mi serve per sapere quante pagine ho per ogni sezione
	for (i=0; i<pages.length; i++) {
		if (pages[i].section=="I") {  
			numI++;
		}
		if (pages[i].section=="P") {
			numP=1;
		}
		if (pages[i].section=="A") {  
			numA++;
		}
		if (pages[i].section=="R") {  
			numR++;
		}
		if (pages[i].section=="F") {
			numF=1;
		}
	}
}

function getSectionFromS(section) {
	if (section=="I") {
		return "Introduzione";
	} else {
		if (section=="P") {
			return "Test d'ingresso";
		} else {
			if (section=="A") {
				return "Argomenti";
			} else {
				if (section=="R") {
					return "Riepilogo";
				} else {
					return "Test finale";
				}
			}
		}
	}
}