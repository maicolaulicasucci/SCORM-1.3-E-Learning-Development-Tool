// Gestione Menu

//Imposto l'hover sul pulsante #menu
function setHover() {
	$("#menu").css("display","block");
	$('#menu').hover(
    function () {
      $('#menu').stop().animate({'marginLeft':'0px'},300);
    },
    function () {
      $('#menu').stop().animate({'marginLeft':'-30px'},300);
    }
  );
}

//Effetto rientro linguetta
$('#menu').ready(function() {
  $('#menu').stop().animate({'marginLeft':'-30px'},1000);
  setHover();
});


$(document).ready(function() {
	$('menu').hide();  //All'inizio nascondo il menu
	loadMenu(); //Carico la lista delle pagine nel menu
	initMenu(); //Inizializzo pulsanti e link del menu
  $('#menu').click(function(e) {
		$('#menu').unbind('mouseenter mouseleave'); //disabilito subito l'hover
    $('#menu').stop().animate({'marginLeft':'-50px'},300, function(){ //nascondo il pulsante sotto il div hide_menu_icon
			$('menu').animate({width: 'toggle'});			
			$("#menu").css("display","none");

		});
		
  });
	
	$('#menu_hover').click(function() {
		$('menu').animate({width: 'toggle'}, function(){
			$('#menu').stop().animate({'marginLeft':'-30px'},300);
			setHover();
		});
	});
	
	//Chiusura del menu con click sulla pagina
	$(document).on("mousedown", function(e) {  //accetto il mousedown perchè con il click mi dà problemi
		var menu = $("menu");
		if (menu.is(":visible")) {
			if (!$(e.target).closest('menu').length) {
				menu.animate({width: 'toggle'}, function(){
					$('#menu').stop().animate({'marginLeft':'-30px'},300);
					setHover();
				});
				e.stopPropagation();
			}
		}
	});
	
});


function initMenu() {
  $('#cssmenu > ul > li:has(ul)').addClass("has-sub");

  $('#cssmenu > ul > li').not(":first-child").not(":last-child").children('a').click(function() {
    var checkElement = $(this).next();
    /*
		La classe clicked serve per mantenere spostato il link a di 15px, in modo da differenziare la pagina aperta 
		La classe active è propria dei li e serve per variare da + a - e viceversa l'icona di apertura sottomenu
		*/
		
    $('#cssmenu li a').removeClass('clicked').closest('li').removeClass("active"); 
		$('#cssmenu li a').not($(this)).animate({'marginLeft':'0px'},300); //riporto tutti a sinistra, tranne il cliccato
    $(this).addClass('clicked').closest('li').addClass("active");	 //attivo clicked e active per il link cliccato
    
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) { //Se ci sono altri sottomenu aperti, li chiudo
      $(this).closest('li').removeClass("active");
      checkElement.slideUp('normal');
    } 
    else {
			if((checkElement.is('ul')) && (!checkElement.is(':visible'))) { //Se il sottomenu cliccato non è visibile lo apro
				$('#cssmenu ul ul:visible').slideUp('normal');
				checkElement.slideDown('normal');
			}
			else {
				$('#cssmenu ul ul:visible').slideUp('normal'); //Se entro qui vuol dire che ho cliccato un link senza sottomenu
			}
		}
			
    
    if (checkElement.is('ul')) {
      return false;
    } else {
      return true;	
    }		
  });
	
	
	$("#cssmenu > ul > li").not(":first-child").not(":last-child").hover( //hover non attivo sul primo/ultimo li
    function () {
			if (!$(this).children('a').hasClass("clicked")) { //se non è già cliccato lo sposto a destra
				$(this).children('a').stop().animate({'marginLeft':'15px'},300);	
			}
    },
    function () {
			if (!$(this).children('a').hasClass("clicked")) {  //quando esco dall'hover se non è cliccato lo riporto a sinistra
      	$(this).children('a').stop().animate({'marginLeft':'0px'},300);
			}
    }
  );
	
	$("#cssmenu ul ul a").click(function(e) { //al click su un link dei sottomenu metto un checkmark o lo tolgo
    //$(this).toggleClass("completed");
  });
}

function loadMenu() {
	for (i=0; i<pages.length; i++) {
		if (pages[i].section=="I") {  //Aggiungo la pagina alla sezione introduzione
			$("#cssmenu > ul > li > ul").eq(0).append("<li><a id='m"+i+"'  onClick='goToPage("+i+");'>"+pages[i].menuTitle+"</a></li>");
			if (pages[i].completed)	$("#m"+i).addClass("completed");

		}
		if (pages[i].section=="P") {
			$("#preTest").attr("onClick","goToPage("+i+")");
		}
		if (pages[i].section=="A") {  //Aggiungo la pagina alla sezione argomenti
			$("#cssmenu > ul > li > ul").eq(1).append("<li><a id='m"+i+"'  onClick='goToPage("+i+");'>"+pages[i].menuTitle+"</a></li>");
			if (pages[i].completed)	$("#m"+i).addClass("completed");
		}
		if (pages[i].section=="R") {  //Aggiungo la pagina alla sezione riepilogo
			$("#cssmenu > ul > li > ul").eq(2).append("<li><a id='m"+i+"'  onClick='goToPage("+i+");'>"+pages[i].menuTitle+"</a></li>");
			if (pages[i].completed)	$("#m"+i).addClass("completed");
		}
		if (pages[i].section=="F") {
			$("#finalTest").attr("onClick","goToPage("+i+")");
		}
	}
}