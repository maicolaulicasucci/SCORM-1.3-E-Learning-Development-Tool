// Gestione comparsa/scomparsa bubbles
function showBubbles(duration) {
  $(".bubble-top").animate({
	  opacity:1,
	  top:'20px'
  },duration);
  $(".bubble-bottom").animate({
	  opacity:1,
	  bottom:'20px'
  },duration);
}

function hideBubbles(duration) {
  $(".bubble-top").animate({
	  opacity:0,
	  top:'-20px'
  },duration);
  $(".bubble-bottom").animate({
	  opacity:0,
	  bottom:'-20px'
  },duration);
}