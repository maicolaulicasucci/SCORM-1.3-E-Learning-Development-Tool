// Gestione test

//INIZIALIZZAZIONE
var currentQuestion = null;
var currentSection = null;
var questionsP = new Array(); //domande pretest
var questionsF = new Array(); //domande test finale
var score = null;
var scoreP = null;
var scoreF = null;
var questions = null;
var finalTest = null;

//Costruttore pagine
function question(question, correctAnswer, studentAnswer) {
	this.question = question;
	this.correctAnswer = correctAnswer;
	this.studentAnswer = studentAnswer;
	this.answers = new Array();
	for (var i = 3; i <arguments.length; i++) {
		this.answers[i-3] = String(arguments[i]);
  }
}

function welcomeQuiz(section) {
	currentSection=section;
	if (currentSection=="P") {
		if (scoreP!=null) { //test già fatto
			score=scoreP;
			printResults();
		} else {
			$("#start-test").show(); //faccio comparire il pulsante
			questions = questionsP;
			$(".test-container").html("<div class='test-text'><p class='test-p'>Nelle pagine seguenti troverai i Test d’ingresso.<br>Attraverso domande a risposta multipla, avrai modo di confrontarti con gli argomenti che verranno trattati.</p><p class='test-p'>Una volta completati i test, sarai più consapevole delle conoscenze e competenze che possiedi già in materia. Allo stesso tempo, avrai evidenziato quali sono gli argomenti che conosci poco o affatto.<br>Quindi, se incontri difficoltà nel rispondere alle domande, non ti preoccupare! Si tratta di test studiati appositamente per introdurti e orientarti all’interno dei contenuti e il cui esito NON INFLUISCE ASSOLUTAMENTE SUL RISULTATO FINALE.<br><span class='bold'>Si ricorda che è possibile effettuare i Test d'ingresso solo una volta.</span></p><p class='test-p'>Dal momento che i test di ingresso hanno una finalità orientativa e non valutativa, sono facoltativi.<br>Pertanto, se non vuoi farli, puoi aprire direttamente il menu di navigazione e cliccare sulla sezione 'Argomenti', oppure puoi premere avanti sul player in basso.</p></div>");
		}
	} else if (currentSection=="F") {
		if (scoreF!=null) {
			score=scoreF;
			printResults();
		} else {
			if (allPagesCompleted()) {
				$("#start-test").show(); //se non ho completato tutte le pagine non accedo ai quiz
			}
			$(".test-container").html("<div class='test-text'><p class='test-p'>Nelle pagine seguenti troverai i Test finali.<br>Attraverso domande a risposta multipla, avrai modo di confrontarti con gli argomenti che sono stati trattati.</p><p class='test-p'><span class='bold'>Si ricorda che per svolgere i Test finali è necessario aver completato tutte i contenuti presenti nel corso.</span> <br>Controlla nel menù di navigazione quale pagine ancora devi ancora completare.</p><p class='test-p'><span class='bold'>Inoltre si ricorda che i test finali si possono sostenere solo una volta.</span><br>Sarà comunque possibile accedere nuovamente ai contenuti del corso, una volta completati.</p><p class='test-p'>Dal momento che i test finali hanno una finalità valutativa, si prega di svolgerli con criterio.</p></div>");
			questions = questionsF;
			finalTest = true;  //flag che serve per salvare le risposte del test finale sul db
		}
	}
	$("header #mainSubtitle").text("Informazioni");
}

function initQuiz() {
	currentQuestion=0;
	score = 0;
	$("#start-test").hide();
	$(".test-button").show();
	$("#test-numero").show();
	$("#totalQ").text(questions.length); // numero totale di domande
	$(".test-container").empty(); //lo svuoto per eliminare la prima pagina dei quiz
	$(".test-container").html("<div class='test-question'></div><form name='quiz' class='test-answers'></form>");
	$("header #mainSubtitle").text("Quesiti");
	loadQuestion();
}

function allPagesCompleted() {
	for (var i=0; i<pages.length-numF;i++) {
		if (!pages[i].completed && pages[i].section!="P") {  //escludo il pretest che può non essere stato completato
			return false;
		}
	}
	return true;
}

function loadQuestion() {
	$("div.test-question").text(questions[currentQuestion].question);
	$("form.test-answers").empty(); //cancello le risposte
	for (var i=0; i<questions[currentQuestion].answers.length; i++) {
		$("form.test-answers").append("<span class='test-answer'><input type='radio' name='q"+currentQuestion+"' value='"+i+"' class='test-radio'>"+questions[currentQuestion].answers[i]+"</span><hr class='test-answer-hr'>");
	}
	$("#currentQ").text(currentQuestion+1);
	
	$(".test-answer").on("click", function(e) {  //attivo il click sulla linea
		if ($(this).children(".test-radio").not(":checked")) {
			$(this).children(".test-radio").prop('checked', true);
			$(".test-answer").not(this).children(".test-radio").prop('checked',false);
		}
	});
	
}

function nextAnswer(){
	if ($("form.test-answers input:checked").length) { //se entro vuol dire che ho cliccato una risposta
		if (currentQuestion < questions.length) {
			questions[currentQuestion].studentAnswer = $("form.test-answers input:checked").val();
			currentQuestion++;
			if (currentQuestion < questions.length) {
				loadQuestion();
			} else {
				updateScore();
				recordTest();
				printResults();	 //domande finite
			}
		}
	}
}

function updateScore() {
	for (var i=0; i < questions.length;i++) {
		if (finalTest) {
			
			ScormProcessSetValue("cmi.interactions."+i+".id","finalQuestion"+i); //label domanda
			ScormProcessSetValue("cmi.interactions."+i+".type","choice"); //tipo di domanda
			ScormProcessSetValue("cmi.interactions."+i+".description",questions[i].question+""); //domanda vera a propria
			ScormProcessSetValue("cmi.interactions."+i+".correct_responses.0.pattern",questions[i].correctAnswer+"");
			ScormProcessSetValue("cmi.interactions."+i+".learner_response",questions[i].studentAnswer+"");
	
			if (questions[i].studentAnswer == questions[i].correctAnswer) {
				ScormProcessSetValue("cmi.interactions."+i+".result","correct");			
				score++;
			} else {
				ScormProcessSetValue("cmi.interactions."+i+".result","incorrect");
			}
		} else {
			if (questions[i].studentAnswer == questions[i].correctAnswer) {
				score++;
			}
		}
	}
}

//called from the test.html page to record the results of a test
//passes in score as a percentage
function recordTest(){
	//normalization
	score = Math.round(score / questions.length * 100);  
	pages[currentPage].completed=true;
	
	if (finalTest) { //savings
		
		scoreF=score; //lo salvo nella variabile relativa al punteggio del test finale
		ScormProcessSetValue("cmi.score.raw", score+"");
		ScormProcessSetValue("cmi.score.min", "0");
		ScormProcessSetValue("cmi.score.max", "100");
		
		var scaledScore = score / 100;
		ScormProcessSetValue("cmi.score.scaled", scaledScore+"");
		
		//consider 60% to be passing
		if (score >= 60){
			ScormProcessSetValue("cmi.success_status", "passed");
			$("#finalTest").children("span").addClass("passed");
		}
		else {
			ScormProcessSetValue("cmi.success_status", "failed");
			$("#finalTest").children("span").addClass("failed");
		}
		
		ScormProcessSetValue("cmi.completion_status", "completed");

	} else {
		scoreP=score;
		if (score>=60) {
			$("#preTest").children("span").addClass("passed");
		} else {
			$("#preTest").children("span").addClass("failed");
		}
	}
}


function printResults() {
	$(".test-button").hide();
	$("#test-numero").hide();
	$(".test-container").empty();
	$("header #mainSubtitle").text("Risultati");
	$(".test-container").html("<div class='test-text'><div class='test-results-completed'>Hai completato il Test.</div><p class='test-p'>Il punteggio che hai raggiunto è: <span id='score'>"+score+"</span> punti.<hr class='test-result-hr'><span class='test-span'>Il punteggio massimo che puoi ottenere è <span id='maxScore'>100</span> punti.</span><hr class='test-result-hr'></p></div>");
	if (score>60) {
		$(".test-text").append("<p class='test-p'>Hai superato il Test!<br>Infatti il Test risulta superato se totalizzi un punteggio di almeno 60 su 100.</p><p class='test-p'>Benissimo! Conosci in maniera approfondita gli argomenti trattati.<br>Adesso puoi uscire e, se ti è utile, riaccedere successivamente ai contenuti utilizzando il menu di navigazione oppure i pulsanti sul player.</p>");
	} else {
		$(".test-text").append("<p class='test-p'>Non hai superato il Test.<br>Infatti il Test risulta superato se totalizzi un punteggio di almeno 60 su 100.</p><p class='test-p'>Peccato! Non conosci in maniera abbastanza approfondita gli argomenti trattati.<br>Adesso puoi uscire e, se ti è utile, riaccedere successivamente ai contenuti utilizzando il menu di navigazione oppure i pulsanti sul player in basso.</p>");
	}
}

function closeTest() {
	$(".test-button").hide();
	$("#test-numero").hide();
	$(".test-container").empty();
	$("header #mainSubtitle").text("Uscita");
	$(".test-container").html("<div class='test-text'><div class='test-results-completed'>Sei uscito dal Test.</div><p class='test-p'>Per continuare cliccare sui pulsanti di navigazione del player oppure del menù a scomparsa.</p></div>");
	
}